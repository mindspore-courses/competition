from .predict import detect

__all__ = ['detect']
