"""
Test example
"""


def test_example():
    """init test example"""
