# ModelArts envs init
pip install albumentations==1.0.3 -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install opencv-python==4.7.0.68 -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install opencv-python-headless==4.7.0.68 -i https://pypi.tuna.tsinghua.edu.cn/simple
echo "ModelArts: pip install albumentations/opencv-python finish."