from .fast_coco_eval_api import COCOeval_fast

__all = ['COCOeval_fast']
