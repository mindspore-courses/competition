# TODO: General label assign method
